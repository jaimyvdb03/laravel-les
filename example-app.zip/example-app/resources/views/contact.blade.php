@extends("layouts.huiswerk")

@section('content')
<div class="container">
    <h1>contact</h1>
    <p>Dit is onze contact gegevens</p>
</div>
@endsection('content')
