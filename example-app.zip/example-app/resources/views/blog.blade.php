@extends('layouts.huiswerk')

@section('content')
       @foreach($article as $articles)

           <h2>{{ $article->title }}</h2>
           <p>{{$article->content}}</p>

       @endforeach
@endsection('content')
