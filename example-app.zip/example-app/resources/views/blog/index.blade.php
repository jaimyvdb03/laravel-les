<?php


public function show()
{
    return view('blog.show');
}

?>
