<?php


public function show()
{
    return view('blog.show');
}

?>
<?php /**PATH C:\xampp\htdocs\example-app\resources\views/blog/index.blade.php ENDPATH**/ ?>